import Hero from "@/components/Hero"
import Features from "@/components/Features"
import AuditForm from "@/components/AuditForm"
import ReportVisualization from "@/components/ReportVisualization"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-900 text-white">
      <Hero />
      <Features />
      <AuditForm />
      <ReportVisualization />
    </main>
  )
}

